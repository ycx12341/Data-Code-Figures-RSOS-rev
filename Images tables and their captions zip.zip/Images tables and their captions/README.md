## Images tables and their captions

This folder contains individual file of each figure, editable file of each table (and their captions) presented in the main body and the supplementary material of Xiao et al, as requested by RSOS.
